#include "sd5.h"

PID_TypeDef Servo_PID;
extern float yaw;

void Servo_init(void)
{
	pwm_init(Servo_PWM_TIM, Servo_PWM_CH1, 100, Servo_Middle_Num);
}

//100HZ
void Servo__Stright_PID_Init(void)
{
		PidInit(&Servo_PID);
	
	Servo_PID.Kp = 40;
	Servo_PID.Ki = 0;
	Servo_PID.Kd = 7;
}

void Servo_Turn_PID_Init(void)
{
	PidInit(&Servo_PID);
	
	Servo_PID.Kp = 37.5;
	Servo_PID.Ki = 0;
	Servo_PID.Kd = 6;
}







