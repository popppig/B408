#ifndef __LINUX_STRING_H__
#define __LINUX_STRING_H__

#include <string.h>

#endif /* __LINUX_STRING_H__ */
